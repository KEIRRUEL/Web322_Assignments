# Web322 Assignment

Student Name: Keir Ruel Lazara
Student Number:  118418235
Student Email:  klazara@myseneca.ca
Date Created:  2024-09-20

GITHUB URL: https://github.com/LeBonbonn/Web322_Assignments
VERCEL URL: https://vercel.com/lebonbons-projects/web322-assignments/78yrPBDWdWPiWBBvMCuRxU4zP6HW  

https://web322-assignments-chi.vercel.app/

https://web322-assignments-git-master-lebonbons-projects.vercel.app/

https://web322-assignments-an4e7mdib-lebonbons-projects.vercel.app/

### Technology Stack

**Frontend**:    
**Backend**: TBD  
**Database**: TBD  

### Notes

By submitting this as my assignment, I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part of this assignment has been copied manually or electronically from any other source (including web sites) or distributed to other students.
