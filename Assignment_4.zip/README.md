# Web322 Assignment

<br/><br/>
Student Name: Keir Ruel Lazara
Student Number: 118418235
Student Email: klazara@myseneca.ca
Date Created: 2024-09-20
<br/><br/>
GITHUB URL: https://github.com/LeBonbonn/Web322_Assignments
<br/><br/>
VERCEL URL: https://vercel.com/lebonbons-projects/web322-assignments/78yrPBDWdWPiWBBvMCuRxU4zP6HW  
<br/><br/>
https://web322-assignments-chi.vercel.app/
<br/><br/>
https://web322-assignments-git-master-lebonbons-projects.vercel.app/
<br/><br/>
https://web322-assignments-an4e7mdib-lebonbons-projects.vercel.app/
<br/><br/>

### Technology Stack

<br/><br/>
**Frontend**:  
**Backend**: TBD  
**Database**: TBD  
<br/><br/>

### Notes

<br/><br/>
By submitting this as my assignment, I declare that this assignment is my own work in accordance with Seneca Academic Policy. No part of this assignment has been copied manually or electronically from any other source (including web sites) or distributed to other students.
In this updated server, what I did is updated the manipulation of output of datas from jason files. Users can now query all categories and articles. They also can
parse if they only want to retrieve a single data from the file. The server is also dynamic and they can also input data and send it on the server.
